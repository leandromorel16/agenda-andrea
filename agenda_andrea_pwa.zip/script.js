
document.getElementById("app").innerHTML = "<p>Pronto podrás ver los turnos aquí.</p>";
